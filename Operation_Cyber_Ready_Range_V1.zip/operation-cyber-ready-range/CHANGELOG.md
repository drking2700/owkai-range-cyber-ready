# Changelog

## 0.1.0 — 2026-09-10

Initial V1 build:
- 16 AI-native cybersecurity missions
- deterministic verification
- AI Work Records
- bounded AI assistance
- AAR workflow
- learner portal
- reviewer console
- GitHub OAuth adapter
- progress/cost index
- devcontainer and CI
- sanitization/secret scanning
- synthetic vertical-slice validation
